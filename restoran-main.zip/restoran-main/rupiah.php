<?php  
function rupiah($str)
{
    return number_format($str, 0, ",", ".");
}
?>